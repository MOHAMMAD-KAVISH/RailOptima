package com.example.railoptima.model

data class Resource(
    val type: String,
    val id: String,
    var status: String
)