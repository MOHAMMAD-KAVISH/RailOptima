package com.example.railoptima.model

data class Schedule(
    val rakeId: String,
    val platform: String,
    val time: String
)